
#import <UIKit/UIKit.h>
#import "IPTableViewController.h"

@interface CommitListViewController : IPTableViewController {

}

@end
