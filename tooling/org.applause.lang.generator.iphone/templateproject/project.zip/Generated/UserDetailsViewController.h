
#import <UIKit/UIKit.h>
#import "IPDetailsViewController.h"

@interface UserDetailsViewController : IPDetailsViewController {

}

@end
